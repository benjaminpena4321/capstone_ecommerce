//json
var myCat = {
	"name": "Meowsalot",
	"species": "cat",
	"favFood": "tuna"

}


// arrays
var myFavColors = ["blue", "green", "purple"];


var thePets = [
	{
		"name": "Meowsalot",
		"species": "cat",
		"favFood": "tuna"

	},
	{
		"name": "Barky",
		"species": "dog",
		"favFood": "carrots"

	}

]

thePets[1].favFood

//end json



























