<?php 
 $con = mysqli_connect("localhost","root","","capstone_2");


?>