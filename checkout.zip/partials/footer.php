<footer>
		<div class="foot1 row ">
            
                <div class="first-foot col-lg-3">
                   <!--  <p><i class="fab fa-facebook-square"></i></p>
                    <p><i class="fab fa-twitter-square"></i></p> -->
                </div> 
                    
                <div class="col-lg-2">
                    <p><strong style="font-size:15px;">Stay Tuned</strong></p>
                    <p>Connect with us and stay in the loop</p>
                     <i class="fab fa-facebook-square"></i> &nbsp;
                    <i class="fab fa-twitter-square "></i>
                </div>
                

                <div class="col-lg-4">
                   <p><strong>Email Updates</strong></p>
                   <p>Be the first to hear about our offers and announcement</p>
                   <div class="email-foot"><i class="far fa-envelope"></i> email </div>
                </div>

                
                <span class="vl"></span>
               

                <div class="col-lg-3">
                        <p><strong>Contact us</strong></p>
                        <p>Questions? We've got answers. Try us.</p>
                        <div class="email-foot"><i class="far fa-envelope"></i> EMAIL US </div>

                </div> 
           
        </div> 
      

        <div class="foot2 row">
            <center>
                <p>Copyright &copy; -- <span style="color:red;"> The Next Web,</span> Inc. Photography &copy; <span style="color:red;">Benjamin Peña.</span></p>
            </center>
        </div>
	</footer>