<?php include "../partials/header.php"?>


<style>
  ul li > a {
    margin:10px;
    position:relative;
    top:15px;
  }
</style>

<div class="row">
<header style=" background-color:black;">
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
    
    <a class="navbar-brand" style="color:gold;">Admin</a>

    <div>
      <ul style="list-style-type: none;" class="navbar-nav mr-auto  mt-lg-0">
        <li class="nav-item active">
          <a class="nav-link" href="manage_orders.php" style="color:white;"> Orders &nbsp;</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="product.php" style="color:white;">Products &nbsp;</a>
        </li>

        <li  class="nav-item">
          <a class="nav-link" href="../login.php" style="color:white;" >Logout</a>
        </li>
      </ul>

    </div>
    </nav>
</header>
</div>



